package org.role.based.auth.jwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoleBasedAuthTests {

    @Test
    void contextLoads() {
    }

}
